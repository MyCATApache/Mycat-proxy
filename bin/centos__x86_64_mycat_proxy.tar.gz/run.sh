chmod 777 ./luacore_x84_64;./luacore_x84_64 main.lua 8080
